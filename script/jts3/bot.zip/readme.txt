JTS3ServerMod
Author: Stefan Martens

E-Mail:
info@stefan1200.de

Homepage:
http://www.stefan1200.de


-= Table of Contents =-
Copyright
Information
System requirements
How to prevent a flood ban on the TS3 server
General Informations about Installation and Usage
Set up bot (all Operating Systems)
Run bot on Linux
Run bot on Windows
How to get Channel ID / Client Unique ID / Client Database ID / Server Group ID / Channel Group ID
How to get the query login credentials for the bot
Needed Permissions for the bot
Visibility of the bot on Teamspeak
Different Message Types
Global message variables
Usage on Teamspeak Server / Chat Commands
Logfile
You need help?
Credits


-= Copyright =-
This program is free for use, but please notify me if you find a bug or if you have some suggestion.
The author of this program is not responsible for any damage or data loss!
It is not allowed to sell this program for money, it has to be free to get!
The modification of the file content of all included files of the JTS3ServerMod, including this manual, are not allowed!
Decompiling is not allowed! Using parts of the source code in other programs is also not allowed!
The commercial use, that means you get money for a Teamspeak 3 server or a bot of the JTS3ServerMod,
is only allowed with a written permission from the author of the JTS3ServerMod!

Teamspeak 3 is developed by TeamSpeak Systems GmbH, Sales & Licensing by Triton CI & Associates, Inc.
More informations about Teamspeak 3: http://www.teamspeak.com


-= Information =-
This program adds some functions to the Teamspeak 3 server. Here is the feature list:
- Auto Move member of specified server groups to specified channels, if they don't have an own default channel set
- Channel Notify, get a message if a client joins a specified channel
- Server Group Notify, get a message if a member of specified server groups joins the server
- Server Group Protection to kick people which are unauthorized member of a protected server group
- Bad Nickname Check to kick people with a bad name from the server
- Bad Channel Name Check to delete or rename channels with a bad name
- Move idle users to another channel and sends a text message
- Kick idle users with a kick reason
- Send a warning message if someone is idle
- Move to a specified channel if client status is away (after some seconds idle),
  can move back if not away anymore
- Move to a specified channel if client status is headphone or microphone muted (after some seconds idle),
  can move back if not muted anymore
- Move recording users to another channel and sends a text message
- Kick recording users from server with a kick reason
- Send a message every X minutes to virtual server or a special channel
- Send a welcome message to every connecting client, can send a special welcome message to specified server groups
- !lastseen chat command to see somebody's last online time
Anything can be configured in a config file.

Another features are:
- Many bot instances for different Teamspeak 3 servers in one bot process
- Automatic reconnect after connection to Teamspeak 3 server lost
- Chat commands which allows you to send messages, get client information, change configurations, reload config file, quit the bot and much more.
- Slow Mode to use the bot (with limited features) without changing the query_ip_whitelist.txt file.


-= System requirements =-
This program was tested on Windows and Linux (even without X server).
On Mac OS X 10.4+, Solaris and FreeBSD it should run too, but it was not tested. If you can test it, please send me an e-mail.
All you need is a Java SE runtime environment version 5 or newer.
You can get the latest official versions from www.java.com or http://www.oracle.com/technetwork/java/javase/downloads/index.html
Mac OS X 10.4 or newer users may have it already installed.
FreeBSD Users should look at http://www.freebsd.org/java/
Linux users should install the package sun-java6-jre or openjdk-7-jre (on older Linux you can also use sun-java5-jre).
An example on Debian or Ubuntu linux: apt-get install sun-java6-jre
An example on CentOS or Fedora: yum install java-1.6.0-openjdk
An example on OpenSUSE: yast -i java-1_6_0-sun
The package gcj-jre (GNU Java) will not work!

Maybe you want to limit the maximum ram that the bot use. This can be useful on a virtual server.
You can do this by using java command line arguments for the java virtual machine.
If you want to use 30 MB ram as maximum, you can start the bot like this:
java -mx30M -jar JTS3ServerMod.jar
Notice: If you choose a to low value, the bot may not run or is not stable. Useful values are between 30M and 50M.
I did no long time tests on this. The bot needs less ram if you disable the client database cache and using only one bot instance.

Teamspeak 3 server 1.0 or newer is needed, but I recommend always to use the newest version.
And of course a possible connection to the Teamspeak 3 server.

Make sure, that the IP address of the bot is white listed using the query_ip_whitelist.txt file of the Teamspeak 3 server.
For more information check out the topic "-= How to prevent a flood ban on the TS3 server? =-" in this readme file.


-= How to prevent a flood ban on the TS3 server =-
If the bot gets banned after connecting to the TS3 server, check the log file of the bot.
If you see the following line in the log file (the number might be different), the solution should work:
de.stefan1200.jts3serverquery.TS3ServerQueryException: ServerQuery Error 3331: flood ban

Solution:
You should add the IP address of the machine running this bot to the Teamspeak 3 server query_ip_whitelist.txt,
or the anti spam feature of the Teamspeak 3 server will ban this program very often for some minutes.
If the bot runs on the same machine as the TS3 server, you can set 127.0.0.1 in the bot config as address of the TS3 server.
Because 127.0.0.1 is white listed by default.

But if you are unable to change the query_ip_whitelist.txt, try to set the bot_slowmode to 1
in the bot server config file. This slows down the bot connection speed and disables some features.


-= General Informations about Installation and Usage =-
Just fully unpack this ZIP file, keep the directories as they are at the ZIP file.
It is not necessary to put this bot into the same directory as the Teamspeak 3 server,
this bot is a standalone program which just connect to the Teamspeak 3 server telnet query port.

By default there are two main config files, JTS3ServerMod_InstanceManager.cfg and JTS3ServerMod_server.cfg.
The JTS3ServerMod_InstanceManager.cfg contains all informations about virtual bot instances,
which should be started. In this file you can setup more virtual bot instances, if you want to have the bot
on more TS3 servers. The JTS3ServerMod_server.cfg contains all bot settings of a virtual instance.
Each virtual bot instance need an own configuration file.
If you add a new bot to the JTS3ServerMod_InstanceManager.cfg you should copy the server1 directory and rename it like server2.
After you did this, change the config file path to the new one at the new added bot in the JTS3ServerMod_InstanceManager.cfg file.

So open both config files and change it to fit your needs. Everything is explained there.
For more information about the config files read documents/ConfigHelp.html!
But make sure that you save both files in ANSI format (encoding ISO-8859-1) and not unicode.
Important: All other config files (like the advertising, record, idle and welcome messages)
are saved in unicode (without BOM) by default. You can change this encoding in the main config file.

Since this is a command line tool, it needs a shell to display messages on it.
Of course it runs also without an active shell window, simple open the logfile to get all informations.

On Windows you can just open the cmd.exe or use the provided EXE files.
Linux users can run this tool even without X-Server, no GUI will be opened.
If you want to use an X-Server, just start this tool within a Terminal / Shell.
Mac OS X users should open the Terminal too.

If you put the JTS3ServerMod.jar and the config directory (containing the file JTS3ServerMod_InstanceManager.cfg)
in the same directory, you can simply start the server mod by enter
java -jar JTS3ServerMod.jar

On virtual servers you should limit the needed RAM of Java.
More information at the topic "-= System requirements =-", recommended is the following value:
java -mx30M -jar JTS3ServerMod.jar

If you want to save the JTS3ServerMod_InstanceManager.cfg and JTS3ServerMod_InstanceManager.log at
a different location or just with a different name, you can use the -config and -log argument, like this:
java -jar JTS3ServerMod.jar -config cfg/instance.cfg -log log/instance.log

Another argument is -help, which only displays a list of command line arguments and quits.


-= Set up bot (all Operating Systems) =-
Check first if you already have installed Java.
You can check this by writing the following command at the Console / Terminal / Command Prompt:
java -version
You should get the output of the Java version. If not, you must install Java first.
For more informations related to this check the section "System requirements" in this readme file.

After you did this, just fully unpack the ZIP file, where you found this file.
It is not necessary to put this bot into the same directory as the Teamspeak 3 server,
this bot is a standalone program which just connect to the Teamspeak 3 server telnet query port.
In the directory config you will find all configuration files of this bot, which must be changed to fit your needs.

Important settings at the config file JTS3ServerMod_server.cfg,
you must set them right to make sure that the bot will work:
ts3_server_address
ts3_server_query_port
ts3_server_query_login
ts3_server_query_password
ts3_virtualserver_id / ts3_virtualserver_port
bot_slowmode

By default all functions are disabled. Activate them at the bot_functions line like you want.
For more information about the functions read documents/ConfigHelp.html!
But be careful with the following functions, because wrong configuration can make big problems:
BadNicknameCheck
BadChannelNameCheck
InactiveChannelCheck
ServerGroupProtection

If one or more persons should be bot admins, you must set one of the following settings:
Bot Full Admin (all admin commands, only persons you trust!): JTS3ServerMod_InstanceManager.cfg -> bot_fulladmin_list
Bot Admin (only admin commands of the virtual bot instance): JTS3ServerMod_server.cfg -> bot_admin_list

Now all important settings are done. Save all files, but make sure that you save both files
in ANSI format (encoding ISO-8859-1) and not unicode. All other config files (like the advertising,
record, idle and welcome messages) are saved in unicode (without BOM) by default.
You can change this encoding in the config file JTS3ServerMod_server.cfg -> bot_messages_encoding.

To start the bot read the according section:
Run bot on Linux
Run bot on Windows


-= Run bot on Linux =-
The first time start the bot like described at the topic "-= General Informations about Installation and Usage =-".
As soon as everything is running like you want, stop the bot (e.g. using Ctrl + C) and go on with this topic.

One solution is using screen. Installing screen is easy (if not already):
On Debian or Ubuntu:
apt-get install screen
On CentOS or Fedora:
yum install screen
On OpenSUSE:
yast -i screen

After you did this, you can change to the JTS3ServerMod directory with cd and fire the following command:
screen -d -m -S ts3bot java -jar JTS3ServerMod.jar
This starts the bot in a special shell screen named ts3bot.

To open this shell screen named ts3bot, maybe to read the output of the bot, just do:
screen -r ts3bot

To close an opened shell screen without quitting the bot just press the following key combination:
CTRL + A + D

If you run into problems, check the section "System requirements" in this readme file.
It is possible to reduce the amount of memory the bot may use.
This is important on Linux VServers.
The low memory example from there to start the bot with the screen command:
screen -d -m -S ts3bot java -mx30M -jar JTS3ServerMod.jar

Also make sure that your system don't run into the open files limit if you have very much bots running at the same time.
Check the open files value using the following command: ulimit -a
You need around two files for each virtual bot instance. Example: 200 bots need at least an 400 open files limit.
Using the following command you can change that limit: ulimit -n <new limit>
Changing this value has an effect to all processes on your system!
Sometimes this setting reset to the default value. Please check how you can make the new value permanent.


-= Run bot on Windows =-
First way is to start the bot as normal application on Windows.
To do this just run JTS3ServerMod-Windows_NoWindow.exe.
All outputs of the bot will be saved to the log file, which will be created by the bot.
Of course you can put a shortcut of the JTS3ServerMod-Windows_NoWindow.exe to the Windows Auto Start directory,
to start the bot on Windows login, but make sure that the "Start in" directory is the JTS3ServerMod directory.
To open the Windows Auto Start directory, just press the two keys Windows + R and enter: shell:startup

If wanted, you can run the bot as Windows Service, this is more complicated and
should only be done if the bot has to run without a logged in user.
To do so, if not already installed, download the Windows Server 2003 Resource Kit Tools:
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=9d467a69-57ff-4ae7-96ee-b18c4790cffd&displaylang=en
You may get a warning message on newer Windows versions, but on my Windows 7 system anything worked.
Now install the Windows Server 2003 Resource Kit Tools.

For the next steps I prepared a small script which do anything for you.
In the tools sub directory you find the script InstallWindowsService.cmd,
but you have to change that script a little bit. To do this just open that script in a text editor.
The path ResourceKitPath and JTS3ServerModPath must be changed to match your installation.
After saving this changes just run this script with Administrator permissions.

The last step is to start the Service like displayed at the end of this script.

Important:
The Service can start the bot, but not stop it again.
You can do this by a chat command to the bot or with the Task Manager.


-= How to get Channel ID / Client Unique ID / Client Database ID / Server Group ID / Channel Group ID =-
The easiest way to get the Channel ID, Client Unique ID and Client Database ID is
to install a very nice extended info pane template of dante696:
http://addons.teamspeak.com/directory/addon/stylesheets/Extended-Client-Info.html

If you don't want to install it, you can use the bot to get the Channel ID.
Just get the bot running and use the chat command !getchannelid <part of the Channel Name> to get the Channel ID.
As an example: !getchannelid away
If you don't change the default value -1 of bot_channel_id you don't have to know any Channel IDs on first bot start!
But make sure that you are a bot admin or full admin, or you can't use the command.

To copy the Client Unique ID of a client just open the Permissions window of your TS3 client and search for the client
you need within the server groups and make a right click on it. Now you see the context menu entry Copy UniqueID to clipboard.
Just click it and paste it where you need it.
On smaller TS3 servers you can also use the menu entry Permissions -> List All Clients, also here you can copy it
with a right click on the client. But with more than 100 clients on that TS3 server this it not really usable.

The Server Group ID and Channel Group ID will be displayed in the Permissions window after clicking on the TS3 Client menu entry
Permissions -> Server Groups
Permissions -> Channel Groups
Next to the group name you see the ID of the group. Of course you have to be connected to the server.

A small problem is the Client Database ID, because TS Systems removed almost all ways to get it using the TS3 Client.
Currently it is only possible with the optional extended info pane template.
But since JTS3ServerMod 5.3 you can use the Client Unique ID for the chat commands too.
The bot recognize automatically if you use the Client Unique ID and request the Client Database ID from the TS3 Server.


-= How to get the query login credentials for the bot =-
If you host the TS3 server on your own, the easiest way is to use the serveradmin login credentials of the TS3 server.
This already has almost all needed permissions and you don't have any problems with the identity of the bot.

If you don't host the TS3 server on your own or don't like to use the serveradmin account,
you can create new query login credentials with your TS3 client, you just need the permission: b_client_create_modify_serverquery_login
But first create a new TS3 identity for the bot. If you don't do this,
the bot is connected with your identity, which confuse all TS3 clients.

To create a new identity, click on Settings -> Identities -> Add
Enter a name for the identity, something like TS3 bot or JTS3ServerMod. Copy the new Unique ID and close that window.
Now connect to your TS3 server with your TS3 client using this new identity.
Click on More if the identity setting is not visible at the Connect window.
After you did this, connect again as Server Admin, if not already, and open the Permissions -> Server Groups window.
Choose the Server Group you want to use for the bot, like the Server Admin group, and add the new identity to this Server Group
by clicking on Add and paste the new Unique ID here. Make sure that this server group has all needed permissions,
look at "Needed Permissions for the bot" in this readme file for a list.
Connect again with your TS3 client using the new identity, if not still connected.
If you connected to your server multiple times, make sure that the connection tab with the new identity is activated!
Now click on Tools -> ServerQuery Login and enter the login name, you like to have.
Write down the login name, you have chosen, and the password you got from the TS3 client.
Use this new details for the bot now. Make sure that you don't use this identity with your TS3 client anymore.
But keep it saved, because you can use it to change the query login password, if necessary some day.


-= Needed Permissions for the bot =-
Make sure that the following permissions are granted for the bot (in brackets why this permission is needed):
b_channel_delete_flag_force (Bad Channel Name Check)
b_channel_delete_permanent (Bad Channel Name Check)
b_channel_delete_semi_permanent (Bad Channel Name Check)
b_channel_delete_temporary (Bad Channel Name Check)
b_channel_join_ignore_password (Allow joining all channels)
b_channel_join_permanent (Allow joining all channels)
b_channel_join_semi_permanent (Allow joining all channels)
b_channel_join_temporary (Allow joining all channels)
b_channel_modify_name (Bad Channel Name Check)
b_client_channel_textmessage_send (Advertising)
b_client_ignore_sticky (If you work with sticky groups)
b_client_info_view (Welcome Message)
b_client_remoteaddress_view (To display the IP address)
b_client_server_textmessage_send (Advertising)
b_group_is_permanent (The bot stay at this group after reconnecting)
b_serverinstance_permission_list (Displaying missing permission names in log, depends on query account)
b_virtualserver_channel_list (Always needed)
b_virtualserver_channelgroup_client_list (chat command !removechannelgroups)
b_virtualserver_client_dblist (Client Database Cache)
b_virtualserver_client_list (Always needed)
b_virtualserver_info_view (Always needed)
b_virtualserver_notify_register (Always needed)
b_virtualserver_notify_unregister (Always needed)
b_virtualserver_select (To connect, depends on the login details)
b_virtualserver_servergroup_list (Always needed)
i_channel_join_power (Allow joining all channels)
i_channel_modify_power (Bad Channel Name Check)
i_client_complain_power (Many functions if complain is enabled)
i_client_kick_from_channel_power (Bad Channel Name Check)
i_client_kick_from_server_power (Many functions)
i_client_move_power (Many functions)
i_client_permission_modify_power (Server Group Protection)
i_client_poke_power (Many functions if poke is chosen as message mode)
i_client_private_textmessage_power (Always needed)
i_group_member_add_power (Server Group Protection)
i_group_member_remove_power (Server Group Protection)

The Guest Server Query group also needs:
b_serverinstance_permission_list (Displaying missing permission names in log, depends on query account)
b_serverquery_login (To connect)
b_virtualserver_select (To connect, depends on the login details)


-= Visibility of the bot on Teamspeak =-
By default the bot will be invisible on the Teamspeak 3 server, because it is just a telnet client
and not a real Teamspeak 3 client. With default permission settings it is easy to make the bot visible
for Teamspeak 3 server administrators. Just open the Teamspeak 3 client Bookmarks -> Manage Bookmarks ->
select the server entry and click on More, if not already. Now activate the option "Show ServerQuery clients".
Now you should be able to see the bot in the Teamspeak 3 client. If still not,
check the permissions like I wrote in the next paragraph.

If you also want to allow other server groups to see the bot, just add the permission
i_client_serverquery_view_power to that group. Use a higher value than the i_client_needed_serverquery_view_power of the bot.
But every client still need the setting in the options to see the bot.


-= Different Message Types =-
You can choose different message types for the most functions of the bot,
check the default JTS3ServerMod_server.cfg file for this.
Currently there are chat and poke valid, at some functions you can also use none to disable sending a message.
Depends on Teamspeak 3 server limits, you can only use 100 characters for a poke message,
including spaces and BBCode. Chat messages have a much higher limit at 1023 characters,
also including spaces and BBCode. You should pay attention to this limits, or the bot can't send
any message and you will find an error in the logfile of the bot.

If a message will be send as kick reason, the maximum character count for the kick reason is 80.


-= Global message variables =-
If enabled in bot configuration, you can use the following global variables for all messages:
%SERVER_NAME% - Server name
%SERVER_PLATFORM% - Server platform (Windows, Linux, ...)
%SERVER_VERSION% - Server version
%SERVER_CREATED_DATE% - Server created date
%SERVER_UPTIME% - Server uptime in days, hours, ...
%SERVER_UPTIME_DATE% - Server uptime as date
%SERVER_UPLOAD_QUOTA% - Server upload quota
%SERVER_DOWNLOAD_QUOTA% - Server download quota
%SERVER_MONTH_BYTES_UPLOADED% - Uploaded data in current month (filetransfer and avatar)
%SERVER_MONTH_BYTES_DOWNLOADED% - Downloaded data in current month (filetransfer and avatar)
%SERVER_TOTAL_BYTES_UPLOADED% - Uploaded data all times (filetransfer and avatar)
%SERVER_TOTAL_BYTES_DOWNLOADED% - Downloaded data all times (filetransfer and avatar)
%SERVER_MAX_CLIENTS% - Server max clients (slots)
%SERVER_RESERVED_SLOTS% - Server reserved slots
%SERVER_CHANNEL_COUNT% - Current channel count
%SERVER_CLIENT_COUNT% - Current client count
%SERVER_CLIENT_DB_COUNT% - Full client count of the TS3 database
%SERVER_CLIENT_CONNECTIONS_COUNT% - Server client connections count
Most server information are not updated instantly, they will be updated every 60 seconds.
If you don't need this variables, disable the global message variables in your bot configuration to save performance!


-= Usage on Teamspeak Server / Chat Commands =-
Since version 1.0 it is possible to use some bot commands in the chat of the Teamspeak 3 server.
You can use the server, channel or private chat. Of course you have to be in the same channel for the channel chat.
Too many commands exists to list them here. Just do in Teamspeak server, channel or private chat: !bothelp
This displays a list of all commands. To check if the bot is running, you can also type: !botinfo
To be a bot admin, you must enter your public unique ID of your client in the bot config file.
There is also a list of all bot commands in documents/ChatCommandHelp.html

Since bot version 3.1 there are two different bot admins possible.
You can set full admins in the JTS3ServerMod_InstanceManager.cfg file,
normal bot admins are set in each virtual bot instance config file for every server.
Full bot admins can use all bot commands on every bot instance, only add persons you trust!
Normal bot admins are limited to the own bot instance and cannot use the following commands:
!exec, !execwait, !botquit, !botinstancelist, !botinstancestart, !botinstancestop


-= Logfile =-
This program creates a logfile with the name JTS3ServerMod_InstanceManager.log.
But this program will also run and work, if it cannot write or create this log file.
The logfile of the InstanceManager contains informations and errors about starting and stopping virtual bot instances.

Each bot instance can create an own log file, this can be set in JTS3ServerMod_InstanceManager.cfg for every virtual bot instance.
By default the log file is named JTS3ServerMod_server1.log for the first virtual bot instance.
A virtual bot instance logs all actions on Teamspeak server and of course all errors while doing this.


-= You need help? =-
Of course you can write an email to me and try to explain your problem (what happens when?).
But please add config and log files of the bot to your email.

If you need more information how to setup the bot correctly, please make sure that you read this file completely.
More information about the bot config files are written down in the documents/ConfigHelp.html file.
Make sure that you read that too.


-= Credits =-
For bug reporting, sending suggestions and testing a thanks flies to:
- 130ng0
- ADM24
- Adam M.
- Ahmet I.
- André A. / Kartoffel-Stampfer
- Atranox / End-Gaming.eu
- BEN89
- Baggavy J.
- Benjamin B.
- Benjamin L.
- BoKo / WebShell
- Bralosch
- ChoosenEye
- Chris / Orange Bots
- Christoph
- Christopher / Lenzen Networks
- Corba
- DaRkBoZ
- Daniel L.
- DarRoe
- DarkGhost
- David K.
- Denden / TSforYOU
- Dr.No
- DunklerKeks / Dark Empire Clan
- EidEchse
- FRAGGYNZ
- Fabrice
- Felix R.
- Flavio
- Flofus
- FoXFTW
- Frank B.
- Fusionpot
- GWR
- Gamle / MainGaming.dk
- Giftzwerg
- Guus W.
- Heiko
- Hermann W.
- Hinken
- HoschY1987
- Invictus International / TS Server HQ
- IronMC
- Jay / Clanwarz
- Jeremy P.
- Johannes1509
- KingHunt / Gamers Platoon
- Kirbyfan1223
- Lore
- MajorThorn
- Mariuszeq
- Marko M.
- Mateusz Z.
- Megamaluco
- Micha5
- Mikołaj
- MrChicken
- NaTesTa10
- NanooTec
- Nate4ever
- Nobody_cbm / Software Galaxy
- Pascal / Fierlord-Hosting
- Patschi
- Philip H. / squaX
- Pierre N. / Next-Host
- Prototype
- Raiden4918 / Subculture-Gaming
- Robert M.
- Robin B. / TS3-4You
- Rowtag
- Sandro M. / TS Voice
- Saucenteufel
- Sebastian S.
- SkullDrago
- Slater
- Speddyroot
- St3v3
- Stefan R.
- Surf3rDud3
- TS-Coach
- Taishou / NLFS Bündnis
- TeaTow
- Thomas / Science System
- ThomasHH / thl-online
- TotoIsBack
- Tukaa
- WaterFlow
- Yanek
- barricas
- cigaming
- dukio
- eggster
- elpoepel
- kadama / Oxivoice
- livedisco
- mastermax
- mathewitp / Old Dragons
- mthomas
- sojakfa
- thecrew
- tigerle
- whvler
- xeomueller / xgs.in
- xoun
List in alphabetical order.